<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: js/src/components/SettingsReplacementVariableEditor.js:33
	__( 'Modify your meta description by editing it right here', 'wordpress-seo' ),

	// Reference: js/src/containers/SnippetEditor.js:103
	__( 'Please provide a meta description by editing the snippet below.', 'wordpress-seo' ),

	// Reference: js/src/containers/SnippetEditor.js:97
	__( 'Snippet preview', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:100
	__( 'Current year', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:15
	__( 'Date', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:20
	__( 'ID', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:25
	__( 'Page', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:30
	__( 'Search phrase', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:35
	__( 'Tagline', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:40
	__( 'Site title', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:45
	__( 'Category', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:50
	__( 'Focus keyword', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:55
	__( 'Title', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:60
	__( 'Parent title', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:65
	__( 'Excerpt', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:70
	__( 'Primary category', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:75
	__( 'Separator', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:80
	__( 'Excerpt only', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:85
	__( 'Category description', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:90
	__( 'Tag description', 'wordpress-seo' ),

	// Reference: js/src/values/defaultReplaceVariables.js:95
	__( 'Term description', 'wordpress-seo' )
);
/* THIS IS THE END OF THE GENERATED FILE */
